package autohedgerconsumer.zmq.FirstAttempt;

import autohedger.splitter.ConfigThreeWaysSplitter;
import autohedger.splitter.ConfigTwoWaysSplitter;
import exceed.core.Books;
import exceed.models.Calendar;
import exceed.models.Common;
import exceed.models.wrappers.CustomerBook;
import exceed.models.wrappers.Trade;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

//import com.trueaccord.scalapb.json.JsonFormat;
import com.google.protobuf.util.JsonFormat;
//import scalapb.json4s.JsonFormat;

public class SplitterUseCase {
    final LocalDate valueDate = LocalDate.of(2017, 07, 28); // today is 27/07, spotDate is t+1
    final LocalDate eurusdValueDate = LocalDate.of(2017, 07, 31); // today is 27/07, eurusd spotDate is @ t+2

    final String pairCADTRY = "CADTRY";
    final ConfigThreeWaysSplitter configCADTRY = new ConfigThreeWaysSplitter("CADTRY_config", Arrays.asList("EURTRY", "USDCAD"), pairCADTRY, "EURUSD");
    Trade cadtry_Deal = new TradeUtil(1_000_000, 2.8575101, "CADTRY", Common.Side.BUY, Common.Dealt.BASE, valueDate, valueDate, "SPOT", "", "","CLIENT").getSpotDeal();


    final String pairEURCAD = "EURCAD";
    final ConfigTwoWaysSplitter configEURCAD = new ConfigTwoWaysSplitter("EURCAD_config", Arrays.asList("EURUSD", "USDCAD"), "USD", pairEURCAD);
    final Trade eurcad_Deal = new TradeUtil(1_000_000, 1.4503, pairEURCAD, Common.Side.BUY, Common.Dealt.BASE, valueDate, valueDate, "SPOT", "", "","CLIENT").getSpotDeal();

    CustomerBook EURUSD_book = new CustomerBook();
    CustomerBook EURTRY_book = new CustomerBook();
    CustomerBook USDCAD_book = new CustomerBook();

    Map<String, CustomerBook> customerBookMap = new HashMap<>();

    Calendar.Tenor tTwoSpotTenor =  Calendar.Tenor.newBuilder()
            .setTenorName("SPOT")
            .setValueDate(DateTimeFormatter.BASIC_ISO_DATE.format(valueDate))
            .build();


    Calendar.Tenor tOneSpotTenor =  Calendar.Tenor.newBuilder()
            .setTenorName("SPOT")
            .setValueDate(DateTimeFormatter.BASIC_ISO_DATE.format(valueDate))
            .build();


    Calendar.TenorDates tenorDatesEURTRY  =  Calendar.TenorDates.newBuilder()
            .setSymbol("EURTRY")
            .addTenor( 0, tOneSpotTenor)
            .build();

    Calendar.TenorDates tenorDatesUSDCAD =  Calendar.TenorDates.newBuilder()
            .setSymbol("USDCAD")
            .addTenor(0,  tOneSpotTenor)
            .build();

    Calendar.TenorDates tenorDatesEURUSD =  Calendar.TenorDates.newBuilder()
            .setSymbol("EURUSD")
            .addTenor(0, tTwoSpotTenor)
            .build();

    autohedger.support.Calendar calendarEURUSD = new autohedger.support.Calendar(tenorDatesEURUSD);
    autohedger.support.Calendar calendarUSDCAD = new autohedger.support.Calendar(tenorDatesUSDCAD);
    autohedger.support.Calendar calendarEURTRY = new autohedger.support.Calendar(tenorDatesEURTRY);

    final Map<String, autohedger.support.Calendar> calendars = new HashMap<String, autohedger.support.Calendar>();

    public void setUp(){

        calendars.put(calendarEURUSD.getSymbol(), calendarEURUSD);
        calendars.put(calendarUSDCAD.getSymbol(), calendarUSDCAD);
        calendars.put(calendarEURTRY.getSymbol(), calendarEURTRY);

        final LocalDate valueDate = LocalDate.of(2017, 07, 28); // today is 27/07, spotDate is t+1
        final LocalDate eurusdValueDate = LocalDate.of(2017, 07, 31); // today is 27/07, eurusd spotDate is @ t+2

        EURUSD_book.addAskQuote(
                "TOM",
                valueDate,
                "EUR",
                "USD",
                Common.Dealt.BASE,
                1_000_000,
                1.14005,
                0.000595);

        EURUSD_book.addAskQuote(
                "SPOT",
                eurusdValueDate,
                "EUR",
                "USD",
                Common.Dealt.BASE,
                10_000_000,
                1.14005,
                0.000595);

        EURUSD_book.addBidQuote(
                "TOM",
                valueDate,
                "EUR",
                "USD",
                Common.Dealt.BASE,
                1_000_000,
                1.14003,
                -0.00058);

        EURUSD_book.addBidQuote(
                "SPOT",
                eurusdValueDate,
                "EUR",
                "USD",
                Common.Dealt.BASE,
                10_000_000,
                1.14003,
                -0.00058);

        EURTRY_book.addAskQuote(
                "TOM",
                valueDate,
                "EUR",
                "TRY",
                Common.Dealt.BASE,
                1_000_000,
                4.13198,
                0.000595);

        EURTRY_book.addAskQuote(
                "SPOT",
                eurusdValueDate,
                "EUR",
                "TRY",
                Common.Dealt.BASE,
                10_000_000,
                4.13198,
                0.000595);

        EURTRY_book.addBidQuote(
                "TOM",
                valueDate,
                "EUR",
                "TRY",
                Common.Dealt.BASE,
                1_000_000,
                4.03198,
                -0.00058);

        EURTRY_book.addBidQuote(
                "SPOT",
                eurusdValueDate,
                "EUR",
                "TRY",
                Common.Dealt.BASE,
                10_000_000,
                4.03198,
                -0.00058);

        USDCAD_book.addAskQuote(
                "TOM",
                valueDate,
                "USD",
                "CAD",
                Common.Dealt.BASE,
                1_000_000,
                1.252040,
                0.000595);

        USDCAD_book.addAskQuote(
                "SPOT",
                eurusdValueDate,
                "USD",
                "CAD",
                Common.Dealt.BASE,
                10_000_000,
                1.252040,
                0.000595);

        USDCAD_book.addBidQuote(
                "TOM",
                valueDate,
                "USD",
                "CAD",
                Common.Dealt.BASE,
                1_000_000,
                1.25188,
                -0.00058);

        USDCAD_book.addBidQuote(
                "SPOT",
                eurusdValueDate,
                "USD",
                "CAD",
                Common.Dealt.BASE,
                10_000_000,
                1.25188,
                -0.00058);

        EURUSD_book.setReferenceMid(11400500000L);
        USDCAD_book.setReferenceMid(12518800000L);
        EURTRY_book.setReferenceMid(40319800000L);

        Books.CustomerBook EURUSD_pb_book = EURUSD_book.toProtobuf();
        Books.CustomerBook USDCAD_pb_book = USDCAD_book.toProtobuf();
        Books.CustomerBook EURTRY_pb_book = EURTRY_book.toProtobuf();

        // to parse to json
        try {
            String EURUSD_json = JsonFormat.printer().preservingProtoFieldNames()
                    .includingDefaultValueFields()
                    .print(EURUSD_pb_book);
        }catch (Exception e) {
            throw new RuntimeException("Error serializing protobuf to json", e);
        }

        // read from json
        Books.CustomerBook.Builder EURUSD_pb_book_ = Books.CustomerBook.newBuilder();
        try(InputStream input = new FileInputStream("c:\\data\\input-text.txt");) {
            try {
                Reader reader = new InputStreamReader(input);
                try {
                    JsonFormat.parser().merge(reader, EURUSD_pb_book_);
                } finally {
                    reader.close();
                }
            } finally {
                input.close();
            }
        }catch(Exception e) {
            throw new RuntimeException("Error deserializing protobuf from json", e);
        }

        customerBookMap.put("USDCAD",USDCAD_book);
        customerBookMap.put("EURUSD",EURUSD_book);
        customerBookMap.put("EURTRY",EURTRY_book);
    }

}
