package autohedgerconsumer.zmq.FirstAttempt

import org.zeromq.ZContext
import zmq.ZMQ

object zmqCBPub extends App {
  val zmqPUB = new zmqCBPub
  val zmqThreadPUB = new Thread(zmqPUB, "MY_PUB")

  //zmqThreadPUB.setDaemon(true)
  zmqThreadPUB.start()
}

class zmqCBPub() extends Runnable {

    override def run() {
      var count = 0

      val ZMQcontext = new ZContext()// ZMQ..context(1)
      val publisher = ZMQcontext.createSocket(ZMQ.ZMQ_PUB)

      publisher.connect(s"tcp://127.0.0.1:16666")

      while (!Thread.currentThread().isInterrupted) {
        try {
          println(s"PUBLISHER -> $count")
          publisher.send(s"PUBLISHER -> $count")
          count += 1
          Thread.sleep(1000)
        }
        catch {
          case e: Exception =>
            println(e.getMessage)
            publisher.close() //.disconnect(s"tcp://127.0.0.1:16666")
            ZMQcontext.close()
            ZMQcontext.destroy()
        }
      }
    }
  }
