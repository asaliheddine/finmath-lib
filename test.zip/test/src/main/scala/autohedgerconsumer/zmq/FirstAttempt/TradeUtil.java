package autohedgerconsumer.zmq.FirstAttempt;

import exceed.core.Trades;
import exceed.models.Common;
import exceed.models.wrappers.Leg;
import exceed.models.wrappers.Trade;

import java.time.LocalDate;

import static exceed.core.Trades.DealType.CLIENT;
import static exceed.core.Trades.DealType.HEDGE;

/*
public class TradeUtil {
}

package autohedger.pos;

        import exceed.core.Trades;
        import exceed.models.Common;

        import exceed.models.wrappers.Trade;
        import exceed.models.wrappers.Leg;

        import java.time.LocalDate;

        import static exceed.core.Trades.DealType.CLIENT;
        import static exceed.core.Trades.DealType.HEDGE;

*/
final public class TradeUtil {

    private double baseNotional, termNotional;
    private  double spotPlusFwddRate;

    final private  String symbol;

    private Common.Dealt dealtCCy;

    final private Trade deal = new Trade();
    final private Leg leg = deal.addLeg();

    private LocalDate spotDate;

    public TradeUtil(double dealtAmount,
                     double spotPlusForwardRate,
                     String ccyPair,
                     Common.Side dealtSide,
                     Common.Dealt dealt,
                     LocalDate dealSpotDate,
                     LocalDate valueDate,
                     String tenor,
                     String internalID,
                     String bookingID,
                     String type){

        symbol = ccyPair;

        spotPlusFwddRate = spotPlusForwardRate;

        deal.setDealt(dealt);
        deal.setBaseCurrency(libexceed.utils.SymbolUtils.baseCurrency(symbol));
        deal.setTermCurrency(libexceed.utils.SymbolUtils.termCurrency(symbol));
        deal.setSpotDate(dealSpotDate);

        if(type.equals("CLIENT"))
            deal.setDealType(CLIENT);

        if(type.equals("HEDGE")) {
            deal.setDealType(HEDGE);
            deal.setStatus(Trades.Status.CONFIRMED);
        }

        switch (dealt){
            case BASE:
                baseNotional = dealtAmount;
                termNotional = dealtAmount * spotPlusForwardRate;
                break;
            case TERM:
                baseNotional = dealtAmount / spotPlusForwardRate;
                termNotional = dealtAmount;
                break;
            default:
                break;
        }


        Common.Side oppositeSide = (dealtSide == Common.Side.BUY) ? Common.Side.SELL : Common.Side.BUY;
        switch(dealt){
            case BASE:
                leg.setBaseSide(dealtSide);
                leg.setTermSide(oppositeSide);
                break;
            case TERM:
                leg.setBaseSide(oppositeSide);
                leg.setTermSide(dealtSide);
                break;
            default: break;

        }

        leg.setBaseAmount(baseNotional);
        leg.setTermAmount(termNotional);
        deal.setInternalId(internalID);
        leg.setValueDate(valueDate);
        leg.setTenor(tenor);
        leg.setSpotRate(spotPlusForwardRate);
        // leg.setForwardPoints(spotPlusForwardRate); // shoul be spotPlusForwardRate

    }

    public TradeUtil(double dealtAmount,
                     double spotRateDouble,
                     double forwardPoints,
                     String ccyPair,
                     Common.Side dealtSide,
                     Common.Dealt dealt,
                     LocalDate dealSpotDate,
                     LocalDate valueDate,
                     String tenor,
                     String internalID,
                     String bookingID,
                     String type){

        symbol = ccyPair;

        double spotPlusFwdPnt = spotRateDouble + forwardPoints;

        deal.setDealt(dealt);
        deal.setBaseCurrency(libexceed.utils.SymbolUtils.baseCurrency(symbol));
        deal.setTermCurrency(libexceed.utils.SymbolUtils.termCurrency(symbol));
        deal.setSpotDate(dealSpotDate);

        if(type.equals("CLIENT"))
            deal.setDealType(CLIENT);

        if(type.equals("HEDGE")) {
            deal.setDealType(HEDGE);
            deal.setStatus(Trades.Status.CONFIRMED);
        }

        switch (dealt){
            case BASE:
                baseNotional = dealtAmount;
                termNotional = dealtAmount * spotPlusFwdPnt;
                break;
            case TERM:
                baseNotional = dealtAmount / spotPlusFwdPnt;
                termNotional = dealtAmount;
                break;
            default:
                break;
        }


        Common.Side oppositeSide = (dealtSide == Common.Side.BUY) ? Common.Side.SELL : Common.Side.BUY;
        switch(dealt){
            case BASE:
                leg.setBaseSide(dealtSide);
                leg.setTermSide(oppositeSide);
                break;
            case TERM:
                leg.setBaseSide(oppositeSide);
                leg.setTermSide(dealtSide);
                break;
            default: break;

        }

        leg.setBaseAmount(baseNotional);
        leg.setTermAmount(termNotional);
        deal.setInternalId(internalID);
        leg.setValueDate(valueDate);
        leg.setTenor(tenor);
        leg.setSpotRate(spotRateDouble);
        leg.setForwardPoints(forwardPoints); // shoul be spotPlusForwardRate
    }
    public exceed.models.wrappers.Trade getSpotDeal(){
        return deal;
    }
    public void setDealStatus(Trades.Status status){
        deal.setStatus(status);
    }
}

