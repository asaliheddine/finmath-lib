package autohedgerconsumer.zmq.FirstAttempt

import org.zeromq.ZContext
import zmq.ZMQ

object zmqCBSub extends App {
  //val zmqPUB = new zmqSub
  val zmqThreadPUB = new Thread(new zmqCBSub(), "MY_PUB")

  //zmqThreadPUB.setDaemon(true)
  zmqThreadPUB.start()
}

class zmqCBSub() extends Runnable {

  override def run() {

    println("STARTING SUBSCRIBER")

    val ZMQcontext = new ZContext()// ZMQ..context(1)
    val subscriber = ZMQcontext.createSocket(ZMQ.ZMQ_SUB)

    subscriber.subscribe("".getBytes)

    subscriber.bind(s"tcp://127.0.0.1:16666")

    while (!Thread.currentThread().isInterrupted) {
      try {
        println("waiting")
        val mesg = new String(subscriber.recv(0))
        println(s"SUBSCRIBER -> $mesg")
      }
      catch {
        case e: Exception =>
          println(e.getMessage)
          subscriber.unbind("tcp://127.0.0.1:16666")
          subscriber.close()
          ZMQcontext.close()
          ZMQcontext.destroy()
      }
    }
  }
}