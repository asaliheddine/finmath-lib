package autohedgerconsumer.zmq.AkkaJavaZMQ
/*
import akka.zeromq._
import akka.actor.Actor
import akka.actor.Props
import akka.actor.ActorLogging
import akka.serialization.SerializationExtension
import java.lang.management.ManagementFactory

import akka.zeromq.ZeroMQExtension

import scala.concurrent.duration._

case object Tick
case class Heap(timestamp: Long, used: Long, max: Long)
case class Load(timestamp: Long, loadAverage: Double)

class customerBooksPublisher extends Actor {

 val pubSocket = ZeroMQExtension.get(context.system).newPubSocket(
    new Bind("tcp://127.0.0.1:1235"));

  val memory = ManagementFactory.getMemoryMXBean
  val os = ManagementFactory.getOperatingSystemMXBean
  val ser = SerializationExtension(context.system)

  override def preStart() {
    context.system.scheduler.schedule(1.second, 1.second, self, Tick)
  }

  override def postRestart(reason: Throwable) {
    // don't call preStart, only schedule once
  }

  def receive: Receive = {
    case Tick ⇒
      val currentHeap = memory.getHeapMemoryUsage
      val timestamp = System.currentTimeMillis

      // use akka SerializationExtension to convert to bytes
      val heapPayload = ser.serialize(Heap(timestamp, currentHeap.getUsed, currentHeap.getMax)).fold(throw _, identity)
      // the first frame is the topic, second is the message
      pubSocket ! ZMQMessage(Seq(Frame("health.heap"), Frame(heapPayload)))

      // use akka SerializationExtension to convert to bytes
      val loadPayload = ser.serialize(Load(timestamp, os.getSystemLoadAverage)).fold(throw _, identity)
      // the first frame is the topic, second is the message
      pubSocket ! ZMQMessage(Seq(Frame("health.load"), Frame(loadPayload)))
  }
}

//system.actorOf(Props[HealthProbe], name = "health")
*/
