package autohedgerconsumer.zmq

import org.zeromq._


object zmqPub extends App {
  val zmqPUB = new zmqPub
  val zmqThreadPUB = new Thread(zmqPUB, "MY_PUB")

  //zmqThreadPUB.setDaemon(true)
  zmqThreadPUB.start()
}

class zmqPub() extends Runnable {

    override def run() {
      val ZMQcontext = ZMQ.context(1)
      val publisher = ZMQcontext.socket(ZMQ.PUB)
      var count = 0

      publisher.connect(s"tcp://127.0.0.1:16666")

      while (!Thread.currentThread().isInterrupted) {
        try {
          println(s"PUBLISHER -> $count")
          publisher.send(s"PUBLISHER -> $count")
          count += 1
          Thread.sleep(1000)
        }
        catch {
          case e: Exception =>
            println(e.getMessage)
            publisher.close() //.disconnect(s"tcp://127.0.0.1:16666")
            ZMQcontext.close()
            ZMQcontext.term()
        }
      }
    }
  }
