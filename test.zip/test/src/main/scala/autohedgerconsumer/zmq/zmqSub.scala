package autohedgerconsumer.zmq

import org.zeromq._

object zmqSub extends App {
  //val zmqPUB = new zmqSub
  val zmqThreadPUB = new Thread(new zmqSub(), "MY_PUB")

  //zmqThreadPUB.setDaemon(true)
  zmqThreadPUB.start()
}

class zmqSub() extends Runnable {

  override def run() {

    println("STARTING SUBSCRIBER")

    val ZMQcontext = ZMQ.context(1)
    val subscriber = ZMQcontext.socket(ZMQ.SUB)
    subscriber.subscribe("".getBytes)

    subscriber.bind(s"tcp://127.0.0.1:16666")

    while (!Thread.currentThread().isInterrupted) {
      try {
        println("waiting")
        val mesg = new String(subscriber.recv(0))
        println(s"SUBSCRIBER -> $mesg")
      }
      catch {
        case e: Exception =>
          println(e.getMessage)
          subscriber.unbind("tcp://127.0.0.1:16666")
          subscriber.close()
          ZMQcontext.close()
          ZMQcontext.term()
      }
    }
  }
}