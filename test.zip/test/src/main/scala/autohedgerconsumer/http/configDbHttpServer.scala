package autohedgerconsumer.http

import akka.actor.ActorSystem
import akka.stream.ActorMaterializer
import akka.http.scaladsl.Http
import akka.http.scaladsl.model._
import akka.http.scaladsl.server.Directives._

import scala.io.Source

//https://blog.scalents.com/2017/08/21/how-to-create-an-akka-http-server/
object configDbHttpServer {

  def main(args: Array[String]) {

    implicit val actorSystem = ActorSystem("system")
    implicit val actorMaterializer = ActorMaterializer()


    val route =
      pathSingleSlash{
        get{
          val file = Source.fromInputStream(getClass.getResourceAsStream("/configdbFabio.json"))
          val contents= file.mkString
          file.close()
          val resp: ResponseEntity = HttpEntity(ContentTypes.`application/json`, contents)
          //val resp: ResponseEntity = HttpEntity(ContentTypes.`application/json`,"{\"my_key\":\"my_value\"}")
          //complete ("{\"my_key\":\"my_value\"}")
          complete(HttpResponse(StatusCodes.OK, entity = resp))


        }
      }~
      pathPrefix("exceed"){ ///client/channel_info/v2"){
        get{
          val file = Source.fromInputStream(getClass.getResourceAsStream("/configdbFabio.json"))
          val contents= file.mkString
          file.close()
          val resp: ResponseEntity = HttpEntity(ContentTypes.`application/json`, contents)
          //val resp: ResponseEntity = HttpEntity(ContentTypes.`application/json`,"{\"my_key\":\"my_value\"}")
          //complete ("{\"my_key\":\"my_value\"}")
          complete(HttpResponse(StatusCodes.OK, entity = resp))
        }
      }~
      path("test"){
        get{
          complete {
            "Hello world"
          }

        }
      }
    Http().bindAndHandle(route,"localhost",31141)

    println(s"Server online at http://localhost:31141/")
  }
}
