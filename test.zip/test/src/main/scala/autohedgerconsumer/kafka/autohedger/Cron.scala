package autohedgerconsumer.kafka.autohedger

import java.time._
import java.time.temporal.ChronoUnit

import akka.actor.{ ActorContext, ActorRef, Cancellable }

import scala.concurrent.duration.FiniteDuration

/**
  * @param clock clock @ UTC
  */
class Cron(clock: Clock) {
  def durationFromNow(
                       time: LocalTime,
                       zoneId: ZoneId
                     ): FiniteDuration = {
    import scala.concurrent.duration._

    val znow = ZonedDateTime.of(LocalDateTime.now(clock), zoneId)
    val zonedDateTime = ZonedDateTime.of(LocalDate.now(clock), time, zoneId)

    val mins = znow.until(zonedDateTime, ChronoUnit.MINUTES)
    val adjustedZonedDateTime = if (mins < 1) {
      // Distance from next rescheduling interval is less than 1 minute. Assuming next day.
      zonedDateTime.plusDays(1)
    }
    else zonedDateTime

    val nSecs = ZonedDateTime.now(clock).until(adjustedZonedDateTime, ChronoUnit.SECONDS)
    nSecs.seconds
  }

  def scheduleAt(
                  time: LocalTime,
                  zoneId: ZoneId,
                  target: ActorRef,
                  message: Any
                )(implicit actorContext: ActorContext): Cancellable = {
    val duration = durationFromNow(time, zoneId)
    actorContext.system.scheduler.scheduleOnce(duration, target, message)(actorContext.dispatcher)
  }

  /**
    * true when targetDateTime is within the given interval AND
    * the distance to the end time is greater than one minute
    *
    * @param startDateTime
    * @param endDateTime
    * @param targetDateTime
    * @return
    */
  def withinTimespan(
                      startDateTime: ZonedDateTime,
                      endDateTime: ZonedDateTime,
                      targetDateTime: ZonedDateTime
                    ): Boolean =
    targetDateTime.isAfter(startDateTime) &&
      targetDateTime.isBefore(endDateTime) &&
      targetDateTime.until(endDateTime, ChronoUnit.MINUTES) >= 1

}
