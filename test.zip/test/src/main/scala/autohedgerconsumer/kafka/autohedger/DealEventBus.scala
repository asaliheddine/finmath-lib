package autohedgerconsumer.kafka.autohedger


import akka.event.{ ActorEventBus, LookupClassification }
import exceed.core.Trades
import exceed.models.wrappers.Trade

/**
  * Event bus classifying deals by currency pair
  */
class DealEventBus extends ActorEventBus with LookupClassification {
  type Event = Trades.Trade
  type Classifier = String

  protected def mapSize(): Int = 128

  protected def classify(event: Event): Classifier =
    new Trade(event.toBuilder).getCurrencyPair()

  protected def publish(event: Event, subscriber: Subscriber): Unit =
    subscriber ! event
}