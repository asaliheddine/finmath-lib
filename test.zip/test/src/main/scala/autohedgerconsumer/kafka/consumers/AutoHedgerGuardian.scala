/*package autohedgerconsumer.kafka.consumers
package actors

import java.time._
import java.util.concurrent.ConcurrentHashMap

import akka.actor.{Actor, ActorLogging, ActorRef, Props, Terminated}
import akka.remote.{AssociatedEvent, AssociationErrorEvent, AssociationEvent, DisassociatedEvent}
import autohedgerconsumer.kafka.autohedger
import autohedgerconsumer.kafka.autohedger.DealEventBus

/* SDA import exceed.autohedger.alerts.{ AlertLevel, AlertRecord, AlertSource }
import exceed.autohedger.booking.VoiceBooking
import exceed.autohedger.config.{ AutoHedgerClientInfo, FakeConfigDB }
import exceed.autohedger.cron.Cron
import exceed.autohedger.eventbuses._
import exceed.autohedger.execution.Execution
import exceed.autohedger.kondor.KondorPositionsActor.UpdateParsed
import exceed.autohedger.kondor.{ KondorFileFetcher, KondorPositionsActor, KondorRecord }
import exceed.autohedger.metrics.Metrics
import exceed.autohedger.pricing.{ PricingEndpoint, PricingSubscriptionSupervisor }
import exceed.autohedger.state.{ PositionStatusStore, PriceRateStore, SpotDateStore }
import exceed.autohedger.tradepoint.TradePointChannelBuilder
import exceed.autohedger.riskchecker.{ RiskCheckerEndpoint, ViolationEndpoint }
import exceed.configdb.AutoHedger
import exceed.configdb.CurrencyPrecisions*/
import exceed.core.Books.CustomerBook
import exceed.core.Trades
import exceed.core.Trades.DealType
//SDA import exceed.d3.{ ConcurrentMapCalendarCache, D3CalendarClient, D3CurveClient }
import exceed.models.Calendar.TenorDates
import exceed.models.wrappers.Trade

import scala.concurrent.Future
import scala.util.{ Failure, Success, Try }

/**
  * The AutoHedger Guardian has two states:
  *   - active
  *   - inactive
  *
  * During the **INACTIVE** state every deal is forwarded
  * to the VOICE desk
  *
  * Otherwise, the deal is sent through the AutoHedger for processing
  *
  */
object AutoHedgerGuardian {
  def props(
             clock: Clock,
             deskId: String/* SDA,
             autoHedgerConfigProvider: () => Future[AutoHedger],
             currencyPrecisions: CurrencyPrecisions,
             kafkaProducerService: ActorRef,
             clientInfo: AutoHedgerClientInfo,
             pricingClientInfo: AutoHedgerClientInfo,
             metrics: Metrics */
           ) = Props(new AutoHedgerGuardian(
    clock,
    deskId/* DSA ,
    autoHedgerConfigProvider,
    currencyPrecisions,
    kafkaProducerService,
    clientInfo,
    pricingClientInfo,
    metrics*/
  ))
  //final case class AutoHedgerConfigUpdate(config: AutoHedger)
  final case object AutoHedgerConfigRetry
  final case object AutoHedgerStartup
  final case object AutoHedgerShutdown
  final case object Tick
}
class AutoHedgerGuardian(
                          clock: Clock,
                          deskId: String/*,
                          autoHedgerConfigProvider: () => Future[AutoHedger],
                          currencyPrecisions: CurrencyPrecisions,
                          kafkaProducerService: ActorRef,
                          clientInfo: AutoHedgerClientInfo,
                          pricingClientInfo: AutoHedgerClientInfo,
                          metrics: Metrics*/
                        ) extends Actor with ActorLogging {
  import AutoHedgerGuardian._
  import context.dispatcher
  //SDA import extensions._

  import scala.concurrent.duration._

  val config = context.system.settings.config
  val cron = new autohedger.Cron(clock)
  context.system.eventStream.subscribe(self, classOf[AssociationEvent])

  log.info(s"Position Keeper root is: ${self.path}")
/* SDA
  val positionStatusStore = PositionStatusStore.fromConfig(config)

  val positionStatusMap = new ConcurrentHashMap[String, PositionStatus]

  val voice =
    new VoiceBooking(
      currencyPrecisions,
      clientInfo,
      kafkaProducerService,
      log
    )

  val d3CalendarCache = new ConcurrentMapCalendarCache[TenorDates]
  val d3CalendarClient = context.actorOf(
    D3CalendarClient.props(config, d3CalendarCache),
    name = "d3-calendar"
  )

  val d3CurveClient = context.actorOf(
    D3CurveClient.props(config),
    name = "d3-forward-curve"
  )

  val pricingEngine = context.actorOf(
    PricingEndpoint.props(config.getConfig("services.pricing")),
    "pricing-endpoint"
  )*/

  val dealConsumer = context.actorOf(
    DealConsumer.props(
      config.getConfig("kafka"),
      config.getString("topics.status-deals"),
      //clientInfo,
      callback = deal => self ! deal
    ),
    name = "deal-consumer"
  )

  val primaryPairDealEventBus =
    new DealEventBus()

  override def postStop(): Unit = {
   /* SDA kafkaProducerService ! AlertRecord(
      AlertLevel.Low,
      "AutoHedgerActive",
      AlertSource.AutoHedger,
      s"AutoHedger is now SHUTTING DOWN ($deskId)"
    )*/
  }

  def receive = unconfigured

  def unconfigured: Receive = {
    log.info("Entered UNCONFIGURED state")

    autoHedgerConfigProvider() onComplete {
      case Success(config) =>
        self ! AutoHedgerConfigUpdate(config)
      case Failure(err) =>
        log.error(err, "Caught error while fetching config")
        import scala.concurrent.duration._
        context.system.scheduler.scheduleOnce(30.seconds, self, AutoHedgerConfigRetry)
    }

    {
      case AutoHedgerConfigUpdate(config) =>
        context become chooseState(config)

      case AutoHedgerConfigRetry =>
        context become unconfigured

      case deal: Trades.Trade =>

        metrics.dealsInc()
        log.debug(s"STOPPED state => MOVING $deal")
        voice.forward(new Trade(deal.toBuilder))

      case _ =>
      // ignore other incoming messages

    }
  }

  def inactive(autoHedgerConfig: AutoHedger): Receive = {
    log.info("Entered INACTIVE state")
    kafkaProducerService ! AlertRecord(
      AlertLevel.Low,
      "AutoHedgerActive",
      AlertSource.AutoHedger,
      s"AutoHedger is now INACTIVE ($deskId)"
    )
    cron.scheduleAt(
      autoHedgerConfig.startTime,
      autoHedgerConfig.startTimeTz,
      self, AutoHedgerStartup
    )

    {
      case AutoHedgerStartup =>
        log.info("Received STARTUP message")
        context become active(autoHedgerConfig)

      case AssociatedEvent(laddr, raddr, inbound) =>
        log.debug(s"Re-associated with pricing.")
        context become chooseState(autoHedgerConfig)

      case deal: Trades.Trade =>

        metrics.dealsInc()
        log.debug(s"STOPPED state => MOVING $deal")
        voice.forward(new Trade(deal.toBuilder))

      case _ =>
      // ignore other incoming messages

    }
  }

  def active(autoHedgerConfig: AutoHedger, isReload: Boolean = false): Receive = {
    log.info("Entered ACTIVE state with config {}", autoHedgerConfig)

    kafkaProducerService ! AlertRecord(
      AlertLevel.Low,
      "AutoHedgerActive",
      AlertSource.AutoHedger,
      s"AutoHedger is now ACTIVE ($deskId)"
    )

    val shutdown = cron.scheduleAt(
      autoHedgerConfig.endTime,
      autoHedgerConfig.endTimeTz,
      self, AutoHedgerShutdown
    )

    val ahGuardian = self
    val configFetcher = context.system.scheduler.schedule(120.seconds, 120.seconds) {
      autoHedgerConfigProvider() onComplete {
        case Success(config) =>
          ahGuardian ! AutoHedgerConfigUpdate(config)
        case Failure(err) =>
      }
    }

    val activeChildren = initializeActiveActors(autoHedgerConfig, isReload)
    val List(pricingSubscriptionSupervisor,
    splitters,
    currencyPairGroupPnl,
    cumulativePnlActor,
    kondorPositionsActor,
    violationActor,
    riskChecker) = activeChildren

    val scheduler = context.system.scheduler.schedule(1.second, 1.second, self, Tick)

    {
      case Tick =>
        currencyPairGroupPnl ! Tick
        cumulativePnlActor ! Tick

      case _: AssociationErrorEvent | DisassociatedEvent =>
        // should handle by becoming inactive, then watch
        // and return back to ACTIVE when possible
        log.error("Received association event. Will become INACTIVE.")
        scheduler.cancel()
        configFetcher.cancel()
        shutdown.cancel()
        activeChildren.foreach(context.watch)
        activeChildren.foreach(context.stop)
        context become switchingConfig(activeChildren.filter(_ != context.system.deadLetters), () => inactive(autoHedgerConfig))

      case AutoHedgerShutdown =>
        log.info("Received SHUTDOWN message")
        activeChildren.foreach(context.stop)
        // on shutdown, fetch config again
        scheduler.cancel()
        configFetcher.cancel()
        shutdown.cancel()
        context become unconfigured

      case KondorPositionsActor.UpdateParsedWithStats(stats, UpdateParsed(records)) =>
        log.info("Received first update from Kondor")
        currencyPairGroupPnl ! stats
        records.foreach {
          case (record, deal) =>
            forwardDeal(record, deal, splitters)
        }

      case deal: Trades.Trade =>
        import extensions._
        metrics.dealsInc()
        log.info(s"Received trade $deal")
        if (deal.getDealType == DealType.CLIENT) {
          splitters ! deal.toInverted
        }
        else {
          primaryPairDealEventBus.publish(deal)
        }

      case unwrappedBook: CustomerBook =>
        metrics.customInc()
        currencyPairGroupPnl forward unwrappedBook

      case upd: RiskBandUpdate =>
        currencyPairGroupPnl forward upd

      case upd: StrategyUpdate =>
        currencyPairGroupPnl forward upd

      case upd: SkewUpdate =>
        currencyPairGroupPnl forward upd

      case AutoHedgerConfigUpdate(cfg) =>
        if (cfg.hashCode() != autoHedgerConfig.hashCode()) {
          log.info("Configuration change detected, reloading")
          scheduler.cancel()
          shutdown.cancel()
          configFetcher.cancel()
          activeChildren.foreach(context.watch)
          activeChildren.foreach(context.stop)
          context become switchingConfig(activeChildren.filter(_ != context.system.deadLetters), () => active(cfg, true))
        }

    }
  }

  def switchingConfig(activeChildren: List[ActorRef], fn: () => Receive): Receive = {
    case Terminated(inactiveChild) =>
      val remainingChildren = activeChildren.filter(_ != inactiveChild)
      log.info("{} terminated, {} children remaining", inactiveChild, remainingChildren.size)

      if (remainingChildren.isEmpty) context become fn()
      else context become switchingConfig(remainingChildren, fn)
  }

  def initializeActiveActors(autoHedgerConfig: AutoHedger, isReload: Boolean) = {
    // this should be automatically collected when we become inactive
    // and the pricingSubscriptionSupervisor actor is destroyed
    val internalPricingBus = new InternalPricingSubscriptionEventBus()

    val pricingSubscriptionSupervisor = context.actorOf(
      PricingSubscriptionSupervisor.props(
        pricingEngine,
        config.getInt("services.pricing.subscription-timeout-seconds"),
        config.getString("services.pricing.zeromq-address"),
        pricingClientInfo,
        internalPricingBus
      ),
      name = "pricing-subscriptions"
    )
    val pricingBus =
      PricingSubscriptionBus(
        pricingSubscriptionSupervisor,
        internalPricingBus
      )

    val tradePointChannelBuilder = TradePointChannelBuilder(
      config.getConfig("services.tradepoint")
    )

    val riskChecker = if (config.getBoolean("autohedger.risk-controls")) Some(context.actorOf(
      RiskCheckerEndpoint.props(config.getConfig("services.risk-checker")),
      "risk-checker-endpoint"
    ))
    else Some(context.system.deadLetters)

    val execution: Execution =
      if (config.getBoolean("autohedger.tradepoint"))
        Execution.tradepoint(
          clientInfo = clientInfo,
          channelBuilder = tradePointChannelBuilder,
          timeoutSeconds = config.getInt("services.tradepoint.order-timeout-seconds"),
          cache = PriceRateStore(autoHedgerConfig.symbolConfigs, pricingBus, context),
          calendarStore = SpotDateStore(d3CalendarCache),
          riskChecker = riskChecker,
          alerts = kafkaProducerService
        )
      else Execution.mock(log)

    val ccyPairPositionUpdateBus =
      new PositionStatusEventBus(
        kafkaProducerService,
        positionStatusStore
      )

    val splitters = context.actorOf(
      SplitterSupervisor.props(
        autoHedgerConfig.splitters,
        d3CalendarClient,
        pricingBus,
        primaryPairDealEventBus,
        voice,
        kafkaProducerService
      ),
      name = "splitters"
    )

    val groupConfig = autoHedgerConfig.symbolGroups.head
    // all ah configured symbols
    val configuredSymbols = autoHedgerConfig.symbolGroups.flatMap(_.symbols).distinct

    import extensions._

    val currencyPairGroupPnl = {
      val numeraire = autoHedgerConfig.pnlCcy
      context.actorOf(
        CurrencyPairPositionGroup.props(
          isReload,
          config.getBoolean("autohedger.kondor"),
          autoHedgerConfig.symbolConfigs.filter { case (k, v) => v.splittedInto.isEmpty },
          autoHedgerConfig.currencies.filterNot(_ == numeraire).map { currency =>
            currency -> configuredSymbols.findInverted(currency + numeraire)
          }.toMap,
          autoHedgerConfig.pnlCcy,
          d3CalendarClient,
          execution,
          voice,
          riskChecker,
          pricingBus,
          primaryPairDealEventBus,
          ccyPairPositionUpdateBus,
          positionStatusMap,
          kafkaProducerService
        ),
        name = "currency-pairs"
      )
    }

    val cumulativePnlActor = context.actorOf(
      CumulativePnlActor.props(
        groupConfig,
        groupConfig.allMidSubscriptions(configuredSymbols),
        d3CalendarClient,
        d3CurveClient,
        riskChecker,
        pricingBus,
        ccyPairPositionUpdateBus,
        kafkaProducerService
      ),
      name = "currencies"
    )

    val violationActor = if (config.getBoolean("autohedger.risk-controls"))
      context.actorOf(
        ViolationActor.props(ViolationEndpoint.props(config.getConfig("services.risk-checker")), currencyPairGroupPnl),
        "violation-actor"
      )
    else context.system.deadLetters

    // restore from kondor = on
    val kondorPositionsActor = if (config.getBoolean("autohedger.kondor")) {
      val kondorFetcher = KondorFileFetcher.forConfig(config)

      context.actorOf(
        KondorPositionsActor.props(
          autoHedgerConfig.symbolConfigs.mapValues(_.splittedInto),
          // all ah configured symbols
          autoHedgerConfig.symbolConfigs.map { case (k, _) => k }.toSeq.distinct,
          d3CalendarClient,
          kondorFetcher,
          positionStatusMap,
          kafkaProducerService
        ),
        name = "kondor"
      )
    }
    else context.system.deadLetters

    pricingSubscriptionSupervisor ::
      splitters ::
      currencyPairGroupPnl ::
      cumulativePnlActor ::
      kondorPositionsActor ::
      violationActor :: riskChecker.get :: Nil
  }

  private def forwardDeal(r: KondorRecord, maybeDeal: Try[Trades.Trade], splitters: ActorRef): Unit = {
    maybeDeal match {
      case Success(deal) =>
        log.debug(s"Forwarding position update for '${r.currencyPair}': $deal")
        splitters ! deal
      case Failure(err) =>
        log.debug(s"Dropped position update for '${r.currencyPair}' (reason: $err)")
    }
  }
  private def chooseState(
                           autoHedgerConfig: AutoHedger,
                           now: ZonedDateTime = ZonedDateTime.now(clock)
                         ) = {
    // FIXME actually, it might be startTime > stopTime
    /* The issue here might be that we assume the day is the same, but what if something crosses over
       into the next day? We need to consider that, instead of just using `today` as now.toLocalDate.
       1 - find day in that place
       2 - set time on that date
       3 - check against current time
     */
    val today = now.toLocalDate
    val start = autoHedgerConfig.startZonedDateTime(today)
    val end = autoHedgerConfig.endZonedDateTime(today)
    if (cron.withinTimespan(start, end, now)) {
      log.info(s"State should be ACTIVE: Local time is $now, falls INSIDE the interval: (${autoHedgerConfig.startTime}, ${autoHedgerConfig.endTime})")
      active(autoHedgerConfig)
    }
    else {
      log.info(s"State should be INACTIVE: Local time is $now, falls OUTSIDE the interval: (${autoHedgerConfig.startTime}, ${autoHedgerConfig.endTime})")
      inactive(autoHedgerConfig)
    }
  }

}
*/
