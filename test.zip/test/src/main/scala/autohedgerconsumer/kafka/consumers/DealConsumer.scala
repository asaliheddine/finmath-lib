package autohedgerconsumer.kafka.consumers

import java.util.function.Consumer

import akka.actor.{ Actor, ActorLogging, Props }
import com.typesafe.config.Config
//import exceed.autohedger.config.AutoHedgerClientInfo
import exceed.core.Trades
import exceed.core.Trades.DealType
import exceed.models.wrappers.Trade
import org.apache.kafka.clients.consumer.ConsumerRecord
import unicredit.kafka.clients.KafkaConsumerActor

import scala.util.control.NonFatal

object DealConsumer {
  def props(
             kafkaConfig: Config,
             kafkaTopic: String,
             //clientInfo: AutoHedgerClientInfo,
             callback: Consumer[Trades.Trade]
           ) = Props(new DealConsumer(
    kafkaConfig,
    kafkaTopic,
    //clientInfo,
    callback
  ))
}
class DealConsumer(
                    kafkaConfig: Config,
                    kafkaTopic: String,
                    //clientInfo: AutoHedgerClientInfo,
                    callback: Consumer[Trades.Trade]
                  ) extends Actor with ActorLogging {
  val consumerActor = context.actorOf(
    KafkaConsumerActor.props(kafkaConfig, autoCommit = true),
    name = "Quants-kafka-consumer"
  )

  override def preStart() = {
    consumerActor ! KafkaConsumerActor.ConsumerSubscribe(Seq(kafkaTopic))
    consumerActor ! KafkaConsumerActor.Subscribe

    log.info("Quants Service Started")
  }

  def receive: Receive = {
    case cr: ConsumerRecord[_, _] =>
      try {
        // val key = cr.key().asInstanceOf[Array[Byte]]
        // val s: String = new String(key)
        log.info("Quants Service ConsumerRecord")
        val data = cr.value().asInstanceOf[Array[Byte]]
        val d = Trades.Trade.parseFrom(data)
        val deal = new Trade(d.toBuilder)

        log.debug("Quants deal consumer {} {}", isAutoHedgeDeal(deal) && !isVoiceDeskDeal(deal)
          || isHedge(deal), deal)

        if (isAutoHedgeDeal(deal) && !isVoiceDeskDeal(deal)
          || isHedge(deal)) {
          log.debug("Quants deal callback accepted")
          //callback.accept(d)
        }
      }
      catch {
        case NonFatal(e) =>
          log.error(e, s"Quants DealConsumer: Failure consuming record ")
      }
  }

  private def isAutoHedgeDeal(deal: Trade) = {
    deal.getDeskId.equals("clientInfo.deskId") &&
      deal.getStatus == Trades.Status.BOOKING
  }

  private def isVoiceDeskDeal(deal: Trade) = {
    // deal.getCounterparty == autohedgerDeskId
    deal.getInternalId.startsWith("AH") ||
      (deal.getTraderUsername == "clientInfo.userId" &&
        deal.getQuote.getLeg(0).getAccountId == "clientInfo.accountId")
  }

  private def isHedge(deal: Trade) = deal.getDealType == DealType.HEDGE

  /*def readRecords() ={
    while(true){
      val records=consumerActor..poll(100)
      for (record<-records.asScala){
        println(record)
      }
    }
  }*/
}
