package autohedgerconsumer

import java.time.Clock

import akka.actor.ActorSystem

object AHMain {
  def main(args: Array[String]): Unit = {
    val deskId = "Quant-test"
    val system = ActorSystem.create("Quant-users-service")
    system.log.info("Starting actor with Quants pricing configuration")
    system.actorOf(
      AHBootstrap.props(
        Clock.systemUTC(),
        deskId
      ),
      name = "quants-position-keeper"
    )
  }
}
