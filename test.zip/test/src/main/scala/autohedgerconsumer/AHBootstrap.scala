package autohedgerconsumer

import java.time.Clock
import java.util.Properties

import akka.actor.{Actor, ActorLogging, ActorSystem, Props}
import autohedgerconsumer.kafka.consumers.DealConsumer
import com.typesafe.config.{Config, ConfigFactory}

import scala.concurrent.duration._
import org.apache.kafka.clients.consumer.{ConsumerRecords, KafkaConsumer, OffsetResetStrategy}
import org.apache.kafka.common.serialization.StringDeserializer
import unicredit.kafka.clients.KafkaConsumerActor

import scala.collection.JavaConverters._
import scala.collection.JavaConversions._
import java.util.Collections

import akka.remote.AssociationEvent
import autohedgerconsumer.kafka.autohedger
//import autohedgerconsumer.kafka.consumers.actors.AutoHedgerGuardian
//import autohedgerconsumer.kafka.consumers.actors.AutoHedgerGuardian.AutoHedgerConfigRetry
import exceed.core.Trades
import exceed.models.wrappers.Trade

import scala.util.{Failure, Success}

object AHBootstrap {
  def props(
             clock: Clock,
             deskId: String /* SDA,
             autoHedgerConfigProvider: () => Future[AutoHedger],
             currencyPrecisions: CurrencyPrecisions,
             kafkaProducerService: ActorRef,
             clientInfo: AutoHedgerClientInfo,
             pricingClientInfo: AutoHedgerClientInfo,
             metrics: Metrics */
           ) = Props(new AHBootstrap(
    clock,
    deskId
  ))

  final case object AutoHedgerConfigRetry
}

class AHBootstrap( clock: Clock,
                   deskId: String
                 ) extends Actor with ActorLogging{

  import context.dispatcher

  import scala.concurrent.duration._

  val config = context.system.settings.config
  val cron = new autohedger.Cron(clock)
  context.system.eventStream.subscribe(self, classOf[AssociationEvent])

  log.info(s"Position Keeper root is: ${self.path}")

  val dealConsumer = context.actorOf(
    DealConsumer.props(
      config.getConfig("kafka"),
      config.getString("topics.status-deals"),
      //clientInfo,
      callback = deal => self ! deal
    ),
    name = "deal-consumer"
  )

  def receive = unconfigured

  def unconfigured: Receive = {
    log.info("Entered UNCONFIGURED state")

    /*autoHedgerConfigProvider() onComplete {
      case Success(config) =>
        self ! AutoHedgerConfigUpdate(config)
      case Failure(err) =>
        log.error(err, "Caught error while fetching config")
        import scala.concurrent.duration._
        context.system.scheduler.scheduleOnce(30.seconds, self, AutoHedgerConfigRetry)
    }*/

    {
      /*
      case AutoHedgerConfigUpdate(config) =>
        context become chooseState(config)

      case AutoHedgerConfigRetry =>
        context become unconfigured

      case deal: Trades.Trade =>

        metrics.dealsInc()
        log.debug(s"STOPPED state => MOVING $deal")
        voice.forward(new Trade(deal.toBuilder))
*/
      case _ =>
      // ignore other incoming messages

    }
  }
}
