package autohedgerconsumer

object Main {
  def main(args: Array[String]): Unit = {
    Bootstrap().startServer()
  }
}
