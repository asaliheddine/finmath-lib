package autohedgerconsumer

import java.util.Properties

import akka.actor.ActorSystem
import autohedgerconsumer.kafka.consumers.DealConsumer
import com.typesafe.config.{Config, ConfigFactory}

import scala.concurrent.duration._
import org.apache.kafka.clients.consumer.{ConsumerRecords, KafkaConsumer, OffsetResetStrategy}
import org.apache.kafka.common.serialization.StringDeserializer
import unicredit.kafka.clients.KafkaConsumerActor

import scala.collection.JavaConverters._
import scala.collection.JavaConversions._
import java.util.Collections

import exceed.core.Trades
import exceed.models.wrappers.Trade

object Bootstrap {

  def apply( /*config: Config, */ ): Bootstrap =
    new Bootstrap( /*config, */ ActorSystem.create("users-service" /*, config*/ ))
}

class Bootstrap( /*config: Config, */ actorSystem: ActorSystem) {

  val bootstrapServers = "localhost:29092"

  def startServer(): Unit = {
    /*val props = new Properties()
    props.setProperty("consumer.bootstrap.servers", "localhost:9092")
    val config: Config = ConfigFactory.parseProperties(props)
    */
    val config = ConfigFactory.load("application.conf")

    val tradesTopic = "topics.status-deals"
    val dealsTopic = "topics.status-deals"

    // it should be better to use a config file
    // will do a good cleanup when getting better time
    // val kafkaReader = system.actorOf(KafkaConsumerActor.props(ConfigFactory.load().getConfig("kafka"), false))

    // this one works well with Embedded server
    // val kafkaReader = system.actorOf(KafkaConsumerActor.props(cfg, false))
    // kafkaReader ! KafkaConsumerActor.ConsumerAssign(Seq((topic, 0)))

    // this is the best way to mimic our Exceed api setup
    /*
    val kafkaReader = actorSystem.actorOf(KafkaConsumerActor.props(config, false, 100 millis))

    kafkaReader ! KafkaConsumerActor.ConsumerAssign(Seq((tradesTopic, 0), (dealsTopic, 1)))
    kafkaReader ! KafkaConsumerActor.ConsumerSubscribe(Seq(tradesTopic, dealsTopic))
    kafkaReader ! KafkaConsumerActor.Subscribe*/


    /*val dealConsumer = context. actorSystem.actorOf(
      DealConsumer.props(
        config.getConfig("kafka"),
        config.getString("topics.status-deals"),
        callback = deal => self ! deal
      ),
      name = "deal-consumer"
    )*/
/*
    val TOPIC = config.getString("topics.status-deals")

    val  props = new Properties()
    props.put("bootstrap.servers", "localhost:9092")

    props.put("key.deserializer", "org.apache.kafka.common.serialization.ByteArrayDeserializer")
    props.put("value.deserializer", "org.apache.kafka.common.serialization.ByteArrayDeserializer")
    props.put("group.id", "something")

    val consumer = new KafkaConsumer[Array[Byte], Array[Byte]](props)

    consumer.subscribe(Collections.singletonList(TOPIC))


    while(true){
      //val records=consumer.poll(100)
      val consumer_record : ConsumerRecords[Array[Byte], Array[Byte]]  = consumer.poll(100)
      for (record <- consumer_record.iterator()) {
        //val key = new String(record.key(), "UTF-8")
        //val value = record.value()
        //println(s"Here's your $record")

        val key = record.key().asInstanceOf[Array[Byte]]
        val s: String = new String(key)
        println("Quants Service ConsumerRecord")
        val data = record.value().asInstanceOf[Array[Byte]]
        val d = Trades.Trade.parseFrom(data)
        val deal = new Trade(d.toBuilder)
      }
    }*/
  }
}
